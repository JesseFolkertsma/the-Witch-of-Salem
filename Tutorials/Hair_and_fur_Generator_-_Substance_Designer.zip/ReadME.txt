Hair and fur generator for Substance Designer is a simple tool I created to make my life easier when creating hair planes or fur.

To use it simply load the .sbsar files in to you Substance library, tweak the parameters and enjoy.

Included is also a file called "Hair_Styles_Examples" where you can see how I used the tool to create different types of hair and fur.

You can find some extra explanation at: http://polycount.com/discussion/178345/guide-resources-creating-hair-fur-planes-using-substance-designer/p1?new=1

Any questions or feedback feel free to reach me out at https://twitter.com/rohmizuno.

I hope you enjoy it!


-------NEW-----
I also added now a substance painter version of the file, for more details on the process check the youtube video at:

https://www.youtube.com/watch?v=LC57pzXFkK0&feature=youtu.be

file name is "Hair_fur_Generator_Painter.sbar".

thanks!